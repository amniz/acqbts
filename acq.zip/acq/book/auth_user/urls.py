from django.urls import path,include

from . import views

urlpatterns = [
    
    path('',views.Login_view.as_view(),name='login'),
    path('login',views.Login_user.as_view(),name='user_login'),
    path('signup',views.Signup_user.as_view(),name='user_login'),
    path('register',views.Register_user.as_view(),name='user_login')
]
