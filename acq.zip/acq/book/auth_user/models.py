from django.db import models

# Create your models here.


class Tokenstore(models.Model):

   token = models.CharField(max_length = 5000)
   
