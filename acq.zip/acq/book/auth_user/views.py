from django.shortcuts import render
import jwt
from rest_framework.views import APIView
from .serializers import CreateUserSerializer
from rest_framework.response import Response
from rest_framework.renderers import JSONRenderer
from django.contrib.auth import authenticate
from .models import Tokenstore
from rest_framework.status import (
    HTTP_400_BAD_REQUEST,
    HTTP_404_NOT_FOUND,
    HTTP_200_OK
)

try:
    redis_connection = redis.StrictRedis(host='localhost',

                          port=6379,

                          db=0)
except Exception as e:
    print(e)
   
# create a function
class Login_view(APIView):
    # create a dictionary to pass
    # data to the template
    def get(self,request):
        return render(request, "login.html")

class Login_user(APIView):
    # create a dictionary to pass
    # data to the template
    def post(self,request):
        response = {
        'success': "",
        'data': ""
        }
        username = request.data['username']  # getting the user name

        password = request.data["password"]  # getting the password

        if username is None or password is None:  # validating whether any of the data is none or not
            response['success']='False'
            response['data']='Please provide both username and password'
            return Response(response,status=HTTP_400_BAD_REQUEST)

        user = authenticate(username=username, password=password)  # verifying the user name and password

        if not user:
            response['success']='False'
            response['data']='Invalid Credentials'
            return Response(response,status=HTTP_400_BAD_REQUEST)  # if not found returning

        payload = {
            'id': user.id,
            'username': user.username  # generating payload

        }
        encoded_jwt = jwt.encode(payload, 'secret', algorithm='HS256')  # generating the token
        response['success']='True'
        response['data']=encoded_jwt
        response['payload']=payload
        redis_connection.set('token', encoded_jwt)  # setting the redis cache key
        # return render(request, "dashboard.html",response)    # returning the token for the future requirments
        return Response(response,status=HTTP_200_OK)
class Signup_user(APIView):
    def get(self,request):
        return render(request, "signUp.html")  

class Register_user(APIView):
    def get(self,request):
        response = {
            'success':"",
            'data':""
        }
        print(request.GET['email'])
        serializer_object = CreateUserSerializer()  # creating serializer object
        validated_data={}
        try:
            if request.GET["username"]!= None:
                validated_data["username"]=request.GET['username']
                
            if request.GET["firstname"]!=None:
                validated_data["firstname"]=request.GET['firstname']
                
            if request.GET["lastname"]!= None:
                validated_data["lastname"]=request.GET['lastname']
            if request.GET["email"] !=None:
                validated_data["email"]=request.GET['email']
            if request.GET["password"] != None:
                validated_data["password"]=request.GET['password']
        
            serializer = CreateUserSerializer.create(serializer_object, validated_data=validated_data)  # calling the create
        # method to insert data in the User model
        # current_site = get_current_site(request)  # getting the current domain address
        # mail_subject = 'Activate your account.'  # subject of the mail
        # try:
        #     payload = {  # payload to be in included in the token
        #         'email': serializer.email,
        #         'username': serializer.username,
        #         'userid': serializer.id

        #     }
        # except Exception:
        #     response['data']='email already registered'
        #     response['success']='false'
        #     return respons
            response['data']='Successfully Completed registration'
            response['success']='True'
            return Response(response,status=HTTP_200_OK)
        except Exception as e:
            print('Exception',e)
            response['data']='email already registered'
            response['success']='false'
            return Response(response,status=HTTP_400_BAD_REQUEST)


    
        
         




    



        