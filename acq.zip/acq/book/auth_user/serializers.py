
from rest_framework import serializers
from django.contrib.auth.models import User

class CreateUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['email', 'username', 'password','first_name','last_name']
        # extra_kwargs = {'email': {'unique': True}}
    #  method to create an database entry in the User model
    def create(self, validated_data):
        print("in 1 ",validated_data)
        user = User(
                email=(validated_data['email']),  # getting the email
                username=validated_data['username'],   # getting the username
                first_name=validated_data['firstname'],   # getting the firstname
                last_name=validated_data['lastname']   # getting the lastname
        )
        print("in 2")
        if User.objects.filter(email=validated_data['email']).count() > 0:
            return "email present"
        user.is_active=True  # making the isactive field to False
        user.set_password(validated_data['password'])  # setting the password for the user by hashing
        user.save()  # saving the user
        print("user saved CreateUserSerializer",user)
        return user