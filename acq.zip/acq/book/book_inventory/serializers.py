from .models import Book
from rest_framework import serializers
class BookSerializer(serializers.ModelSerializer):
       class Meta:
        model = Book
        fields ='__all__'


        def create(self, validated_data):
            book = Book(
                book_name=validated_data['book_name'],
                author=validated_data['author'],
                Book_count=validated_data['Book_count'],
            )
            book.save()
            return book
