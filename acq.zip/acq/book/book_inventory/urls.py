from django.urls import path,include

from . import views

urlpatterns = [
    
    path('get/<int:user_id>',views.Get_books.as_view(),name='book'),
    path('add/<int:user_id>',views.Add_books.as_view(),name='add_book'),
    path('borrowed/<int:user_id>',views.Borrowed_Books.as_view(),name='borrow_book'),
    path('borrowed/<int:user_id>,<int:book_id>',views.Borrowed_Books.as_view(),name='borrow_book')
]
