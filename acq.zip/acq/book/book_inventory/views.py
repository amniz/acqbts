from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from rest_framework.views import APIView
from .decorators import login_user
from .models import Book,Bookborrow
from django.contrib.auth.models import User
from rest_framework.response import Response
from .serializers import BookSerializer
from django.db import connection
import datetime
from rest_framework.status import (
    HTTP_400_BAD_REQUEST,
    HTTP_404_NOT_FOUND,
    HTTP_200_OK
)
   
# create a function
class Get_books(APIView):
    # create a dictionary to pass
    # data to the template
    #api to list all the books
    @login_user
    def post(self,request,user_id):
        response={
            "success":"",
            "data":""

        }
        try:
            user=user=User.objects.filter(id=user_id).values()
            super_user=user[0]['is_superuser']
            if super_user==False:
                print("super usetr false")
                response['succes']='false'
                response['data']='should be validated super user'
                return Response(response,status=HTTP_200_OK)
            # return response with template and context
            else:
                book_list=Book.objects.all()
                
                temp_list=[]
                for i in book_list:
                    print("iiii",i)
                    temp_dict={
                    'name':'',
                    'author':''

                    }
                    temp_dict['name']=i.book_name
                    temp_dict['author']=i.author
                    temp_list.append(temp_dict)
                print("temp_list",temp_list)
                return Response(temp_list)
        except Exception as e:
            response['success']='false'
            response['data']=e
            return Response(response,status=HTTP_400_BAD_REQUEST)

class Add_books(APIView):
    @login_user
    def post(self,request,user_id):
        response={
            "success":"",
            "data":""
        }
        try:
            user=user=User.objects.filter(id=user_id).values()
            super_user=user[0]['is_superuser']
            if super_user==False:
                print("super usetr false")
                response['succes']='false'
                response['data']='should be validated super user'
                return Response(response,status=HTTP_200_OK)
            # return response with template and context
            else:
                book_name=request.data.get('book_name'),
                author=request.data.get('author'),
                Book_count=request.data.get('Book_count'),
                print("book_name",book_name)
                print("author",author)
                print("Book_count",Book_count)
                cursor = connection.cursor()
                query2 = "INSERT INTO book_inventory_book values("+book_name+','+author+','+Book_count+")"
                cursor.execute(query2)
                # datas['results'] = cursor.fetchall()
                # create_books=BookSerializer()
                # create_book=create_books.create(request.data)
                response['success']='true'
                response['data']=create_book
                return Response(response,status=HTTP_200_OK)

        except Exception as e:
            print("except e",e)
            response['success']='false'
            response['data']=e
            return Response(response,status=HTTP_400_BAD_REQUEST)


class Borrowed_Books(APIView):
    @login_user
    def get(self,request,user_id):
        response={
            "success":"",
            "data":[]
        }
        try:
            datas=dict()
            cursor = connection.cursor()
            query2="Select * from book_inventory_book Where id=(Select book_id From book_inventory_bookborrow WHERE user_id= %s)"
            cursor.execute(query2,[user_id])
            datas['results'] = cursor.fetchall()
            for i in datas['results']:
                temp_dict = dict()
                temp_dict["book_name"] = i[0]
                temp_dict["author"] = i[1]
                response['data'].append(temp_dict)
            response['success']='true'
            return Response(response,status=HTTP_200_OK)

             
            
        except Exception as e:
            print("except e",e)
            response['success']='false'
            response['data']=e
            return Response(response,status=HTTP_400_BAD_REQUEST)

class Borrow_Books(APIView):
    @login_user
    def get(self,request,user_id):
        response={
            "success":"",
            "data":""
        }
        try:
            datas=dict()
            cursor = connection.cursor()
            query2="INSERT into book_inventory_bookborrow values (%s,%s,%s)"
            cursor.execute(query2,[user_id,book_id,datetime.datetime.now()])
            response['success']='true'
            response['data']='added the book'
            return Response(response,status=HTTP_200_OK)

             
            
        except Exception as e:
            print("except e",e)
            response['success']='false'
            response['data']=e
            return Response(response,status=HTTP_400_BAD_REQUEST)
    



    


                
