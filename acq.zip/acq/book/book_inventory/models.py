from django.db import models
from django.contrib.auth.models import User
import datetime
from datetime import datetime

# Create your models here.

class Book(models.Model):

   book_name = models.CharField(max_length = 50)
   author = models.CharField(max_length = 50)
   Book_count = models.IntegerField()


class Bookdetail(models.Model):
    book_id=models.ForeignKey(Book,on_delete=models.CASCADE,related_name='book')
    book_details=models.CharField(max_length = 500)

class Bookborrow(models.Model):
    user_id=models.ForeignKey(User,on_delete=models.CASCADE,related_name='user')
    book_id=models.ForeignKey(Book,on_delete=models.CASCADE,related_name='book_borrow')
    borrow_date=models.DateTimeField(default=datetime.now(),blank=True,null=True)


